//Compile time error

private enum Fruits
{
 APPLE,

 BANANA,

 MANGO 
}







