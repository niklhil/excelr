//Compile time error

abstract enum Fruits
{
 APPLE,

 BANANA,

 MANGO 
}







