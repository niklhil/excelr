//Compile time error

static enum Fruits
{ 
  APPLE, BANANA, MANGO;
}

