//Compile time error

final enum Fruits
{
 APPLE,

 BANANA,

 MANGO; 
}







