//Compile time error

protected enum Fruits
{
 APPLE,

 BANANA,

 MANGO 
}







