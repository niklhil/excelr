enum Months
{ 
    JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC;  

     //enum Dayz{ SUN, MON, TUE, WED, THU, FRI, SAT; }

     //abstract enum Days{ SUN, MON, TUE, WED, THU, FRI, SAT; }//CE

     //final enum Days{ SUN, MON, TUE, WED, THU, FRI, SAT; }//CE

     //static enum Days{ SUN, MON, TUE, WED, THU, FRI, SAT; } //No Error

     //private enum Days{ SUN, MON, TUE, WED, THU, FRI, SAT; }//No Error

     //protected enum Days{ SUN, MON, TUE, WED, THU, FRI, SAT; }//No Error

     //public enum Days{ SUN, MON, TUE, WED, THU, FRI, SAT; }//No Error
}