//Compilation error

public enum Fruits
{
  APPLE, BANANA, MANGO 
}











