//CE

import java.io.IOException;

class MyThread extends Thread
{
  public void run() throws IOException
  {
    throw new IOException();
  }
}








