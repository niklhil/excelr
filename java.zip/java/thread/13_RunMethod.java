class MyThread extends Thread
{
  void run() //CE
  {
   System.out.println("MyThread");
  }
}