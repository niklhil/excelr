//Top level class can not be decared protected

protected class Test
{
}