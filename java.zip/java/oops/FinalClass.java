// If a class is declared final then its child can not be created.

final class P
{
}

class C extends P  //CE
{
}