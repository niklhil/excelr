//Top level class can not be declared private

private class Test
{
}