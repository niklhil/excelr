class Parent
{
}

class Child extends Parent
{
}