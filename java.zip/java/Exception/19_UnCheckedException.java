class Main
{
   public static void main(String args[])
   {
     int x=25;
     int y=0;
     int r=x/y;  //ArithmeticException
     System.out.println(r); 
   }
}