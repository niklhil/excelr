 class Greetings
{
public static void main (string arg[])
{
system.out.print("Welcome suriya...u can ")
}
}