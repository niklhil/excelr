class Main
{
  public static void main (String args[])
  {
  int x=10;
  System.out.print("x="+x);
}
}