class Main
{
  public static void main(String args[])
  {
     short x=100;
     short y=300;
     short result=x+y;  //CE
     System.out.println("Result : "+result);

  } 
}

