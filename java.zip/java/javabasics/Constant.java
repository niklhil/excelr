class Main 
{
  public static void main (String args[])
{
final double PI=3.142;
System.out.println(PI);
}
}