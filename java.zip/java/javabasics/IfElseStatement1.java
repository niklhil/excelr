class Main
{
   public static void main(String args[])
   {
      char x='A', y='B';

      if(x>y)
      {
          System.out.println("x is greater than y");
      }
      else
      {
          System.out.println("x is not greater than y");
      }
   }
}