class Main 
{
  public static void main (String args[])
{
final double PI=3.142;
float radius =2.0f;
double area = PI*(radius*radius);
System.out.println("Area:"+area);
}
}