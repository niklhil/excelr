class Main
{
   public static void main(String [] args)
   {
       int x=1, y=2, z=3;
       int result= ((x>y)&&(x>z))?x:(y>z)?y:z;
       System.out.println(result);
   }
}




       
		
