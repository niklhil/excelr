class Main
{
   public static void main(String [] args)
   {
       int x=20, y=10;
       int result;

       result=(x>y)? x: y;
       System.out.println(result); 
   }
}




       
		
