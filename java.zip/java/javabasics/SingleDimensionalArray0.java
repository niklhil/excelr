class Main
{
   public static void main(String[]args)
   {
       String fruits[]={"Apple","Banana","Orange","Mango","Grapes"};

       for(int i=0; i<fruits.length; i++)
       {
          System.out.println(fruits[i]);
       }
   }
}