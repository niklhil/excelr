class Main
{
  public static void main(String args[])
  {
     byte x=10;
     byte y=10;
     //byte sum=x+y; //CE
     int sum=x+y; 
     System.out.println("Sum : "+sum);
  } 
}

