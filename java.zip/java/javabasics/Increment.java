class  Main
{
   public static void main(String args[])
   {
      int x=10;
      System.out.println(++x); //11

      int y=10;
      System.out.println(y++); //10
      System.out.println(y);
   }
}