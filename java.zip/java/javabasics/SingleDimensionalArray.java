class Main
{
   public static void main(String args[])
   {
       int x[]={1,2,3,4,5};

       for(int i=0; i<5; i++)
       {
           System.out.println(x[i]);
       }
   }
}