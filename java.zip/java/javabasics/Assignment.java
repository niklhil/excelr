class Main
{
   public static void main(String args[])
   {
      int x=10;
      int y=10;

      if(x==y) 
      {
         System.out.println("Equals");
      }
   }
}