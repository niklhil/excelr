class Main
{
   public static void main(String []args)
   {
       int x=20, y=10;

       System.out.println("(x==y) : " + (x==y));  //false
       System.out.println("(x!=y) : "  + (x!=y));   //true
       System.out.println("(x>y) : "   + (x>y));    //true
       System.out.println("(x<y) : "   + (x<y));    //false
       System.out.println("(x>=y) : " + (x>=y));  //true 
       System.out.println("(x<=y) : " + (x<=y));  //false
   }
}