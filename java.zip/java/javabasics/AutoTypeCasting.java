class Main
{
    public static void main(String args[])
    {
       float x=10.0F;
       int y=10;
       double result=x+y;
       System.out.println("Result : "+result);
    }
}