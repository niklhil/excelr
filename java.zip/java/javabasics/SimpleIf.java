class Main
{
   public static void main(String args[])
   {
      int x=20, y=10;

      if(x>y)
      {
          System.out.println(x+" is greater than "+y);
      }
     
   }
}