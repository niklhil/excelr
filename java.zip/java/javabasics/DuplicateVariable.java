class Main
{
  public static void main (String args[])
 {
   double x=10.25;
   System.out.println(x);
   
   int x=100; //CE
   System.out.println(x);
  }
} 