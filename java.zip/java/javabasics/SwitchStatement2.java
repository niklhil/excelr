class Main
{
  public static void main(String args[])
  {
      int  x=4;

      switch(x)
      {
         case 1:
         case 2:
         case 3:
         case 4:
            System.out.println("Number is less than five");
         break;

         case 5:
         case 6:
         case 7:
         case 8:
            System.out.println("Number is greater than four");
      }
  }
}