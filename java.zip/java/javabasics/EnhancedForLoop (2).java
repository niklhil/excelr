class Main
{
   public static void main(String[]args)
   {
       String fruits[]={"Apple","Banana","Orange","Mango","Grapes"};
 
       for(String fruit : fruits)
       {
            System.out.println(fruit);
       }         
   }
}