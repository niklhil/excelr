class Main
{
  public static void main (String args[])
  {
   int x=20, y=10;
   int sum,difference,product,quotient,remainder ;

   sum        = x+y;
   difference = x-y;
   product    = x*y;
   quotient   = x/y;
   remainder  = x%y;
  
  System.out.println("Sum:"+sum);
  System.out.println("Difference:"+difference);
  System.out.println("Product:"+product);
  System.out.println("Quotient:"+quotient);
  System.out.println("Remainder:"+remainder);
  }
}
   