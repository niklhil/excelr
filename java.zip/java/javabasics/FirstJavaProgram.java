/** This is my first Java program */

class Greetings
{
    public static void main(String args[])
    {
         System.out.print("Welcome...");
    }
}


/**
     class = Keyword
     Greetings   =  Class name
     public static void main(String args[])  = Method header
     public = Access specifier
     static = Modifier
     void = Return type
     main = Mehod name
     String = Builtin class
     args[] = Single dimension array of String type
     System = Builtin class
     out    =   It is an object inside System class 
     print()  = Method used to display out put
*/










