class Main
{
   public static void main(String args[])
   {
      while(false)
      { //CE
          System.out.println("Hello");	
      }
   }
}