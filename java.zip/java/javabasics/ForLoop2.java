class Main
{
  public static void main(String args[])
  {
     for(;false;)
     { //CE
        System.out.println("Hello");
     }
  }
} 
