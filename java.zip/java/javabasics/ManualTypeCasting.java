class Main
{
    public static void main(String args[])
    {
        int x=127;
        byte y=(byte)x;
        System.out.println(y); 
    }
}