class Employee
{
   int empId;	//Instance variable / Non-Static Data Member	
   String ename;	//Instance variable / Non-Static Data Member	
   double esalary;	//Instance variable / Non-Static Data Member	

   static int eCount;  // Static variable / Class Level variable / Static Data Member
}
