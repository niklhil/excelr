//Static methods can access static members.

class Main
{
    static int x=10;

    public static void main(String args[])
    {
        System.out.println(x); //10
    }
}