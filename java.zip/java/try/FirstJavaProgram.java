class Greetings
{
public static void main (String arg[])
{
System.out.print("welcome suriya u can....");
}
}