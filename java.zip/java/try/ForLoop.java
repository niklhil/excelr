class Main
{
  public static void main(String args[])
  {
     int x=2 ,y=3;
       
 for(;x<y;)
{
  System.out.println("Hello");
}
}
}