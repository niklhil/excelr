/*class Fruit
{
public static void main (String args[])
{
System.out.println("Apple");
System.out.println("Oramge");
System.out.println("Grape");
}
} */

class Main
{
public static void main (String args[])
{
int a=127;
float b=1.0f;
float c=a+b;
System.out.print(c);
}
}