abstract class BankAccount
{
  void show()  //Concrete method
  {
    System.out.println("Display customer details here");
  }

  abstract void interestCalculation();  //Abstract methods
}

