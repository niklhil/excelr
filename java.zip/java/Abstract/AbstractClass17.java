//Abstract methods can not be declared final

abstract class X
{
  final abstract void test(); //CE
}









