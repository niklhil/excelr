class BankAccount
{
  void show()
  {
    System.out.println("Display customer details here");
  }

  void interestCalculation(); //CE
}