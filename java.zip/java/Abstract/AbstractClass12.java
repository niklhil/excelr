//Abstract methods can't have a body / Concrete methods can't be declared abstract

abstract class X
{
   abstract void test()   		
   {
     System.out.println("Test");
   } 
}










