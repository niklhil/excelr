abstract class BankAccount 
{
}

class Main
{
  public static void main(String args[])
  {
     BankAccount Obj=new BankAccount(); //CE
  }
}