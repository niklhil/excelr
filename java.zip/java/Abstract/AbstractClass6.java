// Class should be declared abstract if it has any abstract method

class BankAccount   //CE	
{
  void show() 		  //Concrete method
  {
    System.out.println("Display customer details here");
  }

  abstract void interestCalculation();  //Abstract method
}














