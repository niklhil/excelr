//Abstract methods can not be declared private

abstract class X
{
  private abstract void test(); 
}