/* Data memebers can not be abstract, since they can not be overridden */

abstract class X
{
   abstract int x; //CE 
   abstract void test(); 
}









