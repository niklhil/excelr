//Abstract methods can not be declared static

abstract class X
{
  static abstract void test();  //CE
}












