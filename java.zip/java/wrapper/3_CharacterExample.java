class Main
{
  public static void main(String args[])
  {
     byte b=65;   

     //Character c =new Character('A'); //A  
     //Character c =new Character("A"); //CE
     //Character c =new Character(b);//CE 
     Character c =new Character('5'); //5

     System.out.println(c);
   }
}