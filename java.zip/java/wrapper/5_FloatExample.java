class Main
{
   public static void main(String args[])
  {
    Float f =new Float(2); 	//2.0 
    //Float f =new Float(2.0);	//2.0
    //Float f  =new Float("2.5F");	//2.5
    //Float f  =new Float("2.5");	//2.5
    //Float f  =new Float("A"); 	//NFE
    //Float f  =new Float('A');	// 65.0
	
     System.out.println(f);
   }
}