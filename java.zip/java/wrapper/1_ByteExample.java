class Main
{
    public static void main(String args[])
   {
      byte b=10;
      Byte b1=new Byte(b);
      Byte b2=new Byte("20");

      System.out.println(b1);//10
      System.out.println(b2);//20
   }
}

