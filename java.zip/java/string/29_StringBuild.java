/*
  StringBuilder()
  StringBuilder(int Capacity) 
  StringBuilder(String Value)
*/

class Main
{
   public static void main(String args[])
  {
    StringBuilder s=new StringBuilder("George Bush");
    s.reverse();
    System.out.println(s);
  }
}