//public String trim()

class Main
{
  public static void main(String args[])
  {
    String s="     Java        ";
    System.out.println(s);
    s=s.trim();
    System.out.println(s);
  }
}

