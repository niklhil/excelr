//public StringBuffer reverse();

class Main
{
  public static void main(String args[])
  {
     StringBuffer sb=new StringBuffer("ABCD");
     sb.reverse();
     System.out.println(sb); //DCBA
  }
}