//public int length()

class Main
{
  public static void main(String args[])
  {
    String s="George Bush";
    int i=s.length();
    System.out.println(i); //11
  }
}