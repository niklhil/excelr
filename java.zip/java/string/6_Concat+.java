class Main
{
   public static void main(String args[])
   {
      System.out.println("John is "+ 20+5 + " years old"); 
      System.out.println("John is "+ (20+5) + " years old");
      System.out.println(25.20 + "12.50");
      System.out.println(25.28 + "12.50");
      System.out.println("25.28" + 12.50);
   }
}



