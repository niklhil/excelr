//public int compareTo(String s)

class Main
{
  public static void main(String args[])
  {
     String s1="MBA";  
     String s2="MCA";  

     int c= s1.compareTo(s2);
     System.out.println(c); 
   }
}