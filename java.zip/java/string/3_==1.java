class Main
{
   public static void main(String args[])
   {
     String s1="X";  
     String s2="X"; 

     if(s1==s2)
     {
       System.out.println("Same reference");
     } 
     else
     {
       System.out.println("Different references");      
     }
   }
 }