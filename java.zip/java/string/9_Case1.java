class Main
{
  public static void main(String args[])
  {
     String s1="scott";  
     s1=s1.toUpperCase();   
     System.out.println(s1);  //SCOTT
    

     String s2="SCOTT";  
     s2=s2.toLowerCase();  
     System.out.println(s2); //scott
  }
}