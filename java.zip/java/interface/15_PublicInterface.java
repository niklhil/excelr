public interface Drinkable
{
     int QTY=1;
     void drink();
}

