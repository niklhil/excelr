/* Interface can not have public-non-static concrete methods. */

interface Drinkable
{
     int QTY=1;
     void drink(){} //CE  
     void taste();  
}











