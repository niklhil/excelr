/* Constants and abstract methods in interface should always be public. */

interface Drinkable
{
    protected int QTY=1;          
    protected void drink();    
    protected void taste();    
}












