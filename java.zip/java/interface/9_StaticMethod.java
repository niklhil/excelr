/* Undefined methods of the interface can not be static.*/

interface Drinkable
{
      int QTY=1;
      static void drink();  //CE
      static void taste();  //CE
}







