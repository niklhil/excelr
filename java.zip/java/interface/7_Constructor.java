/* Interface does not have constructor. */

interface Drinkable
{
     int QTY=1;
     void drink();
     Drinkable(){} //CE
}







