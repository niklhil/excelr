/* Interface data members are by default public, static & final. */

interface Drinkable
{
     public static final int QTY=1;
     void drink();
     void taste();  
}











