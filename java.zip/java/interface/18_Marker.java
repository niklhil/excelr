/* 
   Interface which does not contain any member in it is called as marker interface. 
   Marker interface  Ex. Cloneable, Serializable

   class Employee implements Cloneable
   {
      // Cloneability of Employee class is enabled.
   }

*/

/*  Marker interface  */
interface X
{
}













