/* Top level class or interface can not be declared static. */

static interface Drinkable 
{
     int QTY=1;
     void drink();
}











