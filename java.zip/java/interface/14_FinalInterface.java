/*Interface can not be declared final. */

final interface Drinkable   //CE
{
   void drink();
}













