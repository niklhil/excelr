/* Interface can be declared abstract. */

abstract interface Drinkable 
{
     int QTY=1;
     void drink();
}












