/* Interface can not have variables. It supports only constants; hence they need to be initialized during declaration itself. */

interface Drinkable
{
     int QTY;   
     void drink();
}












