/* Undefined non-static methods of interface can be declared abstract. */

interface Drinkable
{
     int QTY=1;
     abstract void drink();  
     abstract void taste();  
}












