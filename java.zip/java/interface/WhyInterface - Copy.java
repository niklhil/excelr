/*
 1)    ScientificCalculator :
        void add()
        void subtract()
        void sin()
        void cos()
        void tan()
*/

interface Calculations
{
        void add();
        void subtract();
        void sin();
        void cos();
        void tan();
}


class ScientificCalculator implements Calculations
{
     public void add()
     {
     }

    public void subtract()
     {
     }

   public void sin()
    {
    }

   public void cos()
    {
    }

/*    public void tan()
      {
      }
*/
}













