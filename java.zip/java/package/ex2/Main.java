class Main
{
   public static void main(String args[])
   {
       p1.A a=new p1.A();
       a.show();  //10

       p2.A aa=new p2.A();
       aa.display(); //20
   }
}