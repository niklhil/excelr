package p2;

public class B
{
    private int y=20;

    public void display()
    {
       System.out.println(y);  //20
    }
}