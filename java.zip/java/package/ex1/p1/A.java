package p1;

public class A
{
   private int x=10;

   public void show()
   {
     System.out.println(x); //10
   }
}