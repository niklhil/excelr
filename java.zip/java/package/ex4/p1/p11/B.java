package p1.p11;

import p1.A;

public class B
{
    public void display()
    {
        A a=new A();
        a.show();
    }
}