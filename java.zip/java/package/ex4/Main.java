import p1.A;
import p1.p11.B;

class Main
{
   public static void main(String args[])
   {
      A a=new A();
      a.show();   //10

      B b=new B();
      b.display(); //10
   }
}