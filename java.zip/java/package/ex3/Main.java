import p1.A;
import p1.p11.B;

//import p1.*; //This does not import sub-package

class Main
{
   public static void main(String args[])
   {
      A a=new A();
      a.show();

      B b=new B();
      b.display(); 
   }
}